package com.example.meurastreador;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private Button btBotao = null;
    private Button btAlgo = null;
    private Button btTela = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btBotao = (Button) findViewById(R.id.bt_botao);
        btAlgo = (Button) findViewById(R.id.bt_algo);
        btTela = (Button) findViewById(R.id.bt_tela);

        btBotao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostraMensagem("Atenção", "A vaca morreu");
            }
        });
        btAlgo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"A vaca não morreu!",Toast.LENGTH_SHORT).show();
                //mostraMensagem("Atenção","A vaca não morreu");
            }
        });
        btTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MenuTwo.class);
                intent.setAction(Intent.ACTION_VIEW); // opcional
                startActivity(intent);
            }
        });

    }

    private void mostraMensagem(String titulo, String mensagem) {
        // Dicas: A Classe AlertDialog, possui uma classe estática chamada de Builder
        // que possui vários métodos como setTitle, setMessage, setIcon, ...
        // que retornam um Builder. Dessa forma é possível passar parâmetros
        // encadeados para definição de uma caixa de mensagem
        new AlertDialog.Builder(this).setTitle(titulo).setMessage(mensagem).setNegativeButton("Fechar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                // colocar algum código adicional, caso queira
            }
        }).show();
    }


}
